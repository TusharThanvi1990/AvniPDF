'use client'

import React, { useState } from 'react'
import FileUpload from '../../components/TextExtractor'

export default function Home() {
  

  return (
    <div >
      <FileUpload />
    </div>
  )
}

